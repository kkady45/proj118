var languages = {
    'de' : {
        'interactionButton1' : 'Interaktion 1',
        'interactionButton2' : 'Interaktion 2',
        'interactionButton3' : 'Interaktion 3',
        'interactionButton4' : 'Interaktion 4',
        'interactionButton5' : 'Interaktion 5',
        'interactionButton6' : 'Interaktion 6',
        'interactionButton7' : 'Interaktion 7',
    },
    'en' : {
        'interactionButton1' : 'Interaction 1',
        'interactionButton2' : 'Interaction 2',
        'interactionButton3' : 'Interaction 3',
        'interactionButton4' : 'Interaction 4',
        'interactionButton5' : 'Interaction 5',
        'interactionButton6' : 'Interaction 6',
        'interactionButton7' : 'Interaction 7',
    }
};