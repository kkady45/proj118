 // https://wahrnehmungseffekte.zysen.duckdns.org/interactions/interaction.html?module=2&unit=1&interaction=1
const urlParameters = new URLSearchParams(window.location.search.replace(/&amp;/g, '&'));
